<?php
require('connect.php');


 if(isset($_POST["submit"])){
	$Username = $_POST["Username"];
	$password = $_POST["password"];
	$result = mysqli_query($conn, "SELECT * FROM customer WHERE Username = '$Username'" );
  $row = mysqli_fetch_assoc($result);
  if(mysqli_num_rows($result) > 0){
     if($password == $row["password"]){
      $_SESSION["login"] = true;
      $_SESSION["ID"] = $row["ID"];
      header("location: index.html");
     }
     else{
      echo
      "<script> alert('Worng Password'); </script>";

     }
  }
  else{
    echo
    "<script> alert('User not Registered'); </script>";
  }
  
	$query = "SELECT $Username , $password FROM car rental office ";
	mysqli_query($conn,$query);

  }


?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Insert Data</title>
  </head>
  <style media="screen">
    label{
      display: block;
    }
  </style>
  <style>
body {font-family: Arial, Helvetica, sans-serif; }
form {
  border: 3px solid #C0C0C0; 
  width: 50%;
  margin: auto;
  
  
  
}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 30%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}
h2{
  
}
/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
  
}
</style>
  <body align="center">
    
  <h2>Login Page</h2>
  <div class="imgcontainer">
    <img src="147144.png" alt="Avatar" class="avatar">
  </div>
  
  
  

  
  <form class="" action="" method="post" autocomplete="off">
      <label for="">Username</label>
      <input type="text" name="Username" required value="">
      <label for="">password</label>
      <input type="text" name="password" required value="">
	
      


      <a href="index.html" style="color:dodgerblue"><button type="submit" name="submit">sign in</button></a>
    </form>
  </body>
</html>