<?php
require('connect.php');


 if(isset($_POST["submit"])){
	$Username = $_POST["Username"];
	$password = $_POST["password"];
  $duplicate = mysqli_query($conn, "SELECT * FROM customer WHERE Username = '$Username'" );
  if(mysqli_num_rows($duplicate) > 0){
    echo
    "<script> alert('Username has Already Taken'); </script>";
     
  }
  else{
    $query = "INSERT INTO customer VALUES('$Username','','','','', '','$password','','')";
	  mysqli_query($conn,$query);
    
  }

}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>sign up</title>
  </head>
  <style media="screen">
    label{
      display: block;
    }
  </style>
  <style>
body {font-family: Arial, Helvetica, sans-serif;}
* {
  box-sizing: border-box
  

}

form {
  border: 3px solid #C0C0C0; 
  width: 80%;
  margin: auto;
  
  
  
}
/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 16px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
  <body>
  <h1>Sign Up</h1>
  <p>Please fill in this form to create an account.</p>

  <form class="" action="" method="post" autocomplete="off">
      <label for="">Username</label>
      <input type="text" name="Username" required value="">
      <label for="">password</label>
      <input type="text" name="password" required value="">
	
      


      <p>if you already have an account<a href="login.php" style="color:dodgerblue">  login</a>.</p>

      
      <div class="clearfix">
      <button type="button" class="cancelbtn">Cancel</button>
      <button type="submit" name="submit" class="signupbtn" >Sign Up</button>
    </div>
  </div>
    </form>
  </body>
</html>